class ProviderEntity {
  int? id;
  late String name;
  late String address;
  late String phoneNumber;

  ProviderEntity({required this.name, required this.address, required this.phoneNumber});
}