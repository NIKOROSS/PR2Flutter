class StockEntity {
  int? id;
  late String address;

  StockEntity({required this.address});
}