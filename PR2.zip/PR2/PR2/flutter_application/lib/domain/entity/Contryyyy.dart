class ProductCategoryEntity {
  int? id;
  late String name;
  late String description;

  ProductCategoryEntity({required this.name, required this.description});
}