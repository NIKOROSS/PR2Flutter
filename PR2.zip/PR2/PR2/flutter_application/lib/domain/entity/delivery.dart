class ArrivalEntity {
  int? id;
  late String date;
  late int count;
  late int providerId;
  late int productId;

  ArrivalEntity({required this.date, required this.count, required this.providerId, required this.productId});
}