class IssuePointEntity {
  int? id;
  late String name;
  late String address;

  IssuePointEntity({required this.name, required this.address});
}