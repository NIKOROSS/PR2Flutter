class RoleEntity {
  int? id;
  late String role;

  RoleEntity({required this.role});
}

enum RoleEnum { admin, user }
